## Project Part 2 - Unsupervised Learning (K-means)
### Run main.py to visualize results.
### data_utils.py convers AllSamples.mat to numpy array and stores in Data folder
**random.png** -> Plot for Strategy 1 
**Max.png** -> Plot for Strategy 2